
public class Dispatcher extends DispatcherBase {
    LinkedList planes = new LinkedList();

    /* Implement all the necessary methods of Dispatcher here */
    @Override
    public int size() {
        return planes.size;
    }

    @Override
    public void addPlane(String planeNumber, String time) {
        planes.insert(new Node(new Plane(planeNumber, time)));
    }

    @Override
    public String allocateLandingSlot(String currentTime) {
        if (planes.head == null) {
            return null;
        }
        String[] newCurrentTime = currentTime.strip().split(":");
        int time =
                Integer.parseInt(newCurrentTime[0]) * 60 + Integer
                        .parseInt(newCurrentTime[1]);
        String[] newPlaneTime = planes.head.data.getTime().strip().split(":");
        int planeTime =
                Integer.parseInt(newPlaneTime[0]) * 60 + Integer
                        .parseInt(newPlaneTime[1]);
        String planeNumber = planes.head.data.getPlaneNumber();

        if (planeTime >= time && planeTime <= time + 5) {
            if (planes.head.next == null) {
                planes.head = null;
            } else {
                planes.head = planes.head.next;
                planes.head.prev = null;
            }
            return planeNumber;
        } else if (planeTime < time) {
            planes.head = planes.head.next;
            planes.head.prev = null;
            return planeNumber;
        }
        return null;
    }

    @Override
    public String emergencyLanding(String planeNumber) {
        Node head = planes.head;
        while (head != null) {
            if (head.data.getPlaneNumber().equals(planeNumber)) {
                String removedNumber = head.data.getPlaneNumber();
                //remove middle
                if (head.prev != null && head.next != null) {
                    head.prev.next = head.next;
                    head.next.prev = head.prev;
                    break;
                } else if (head.prev != null) {
                    //remove last one
                    head.prev.next = null;
                    head.prev = null;
                    break;
                } else if (head.next != null) {
                    //remove first one
                    head.next.prev = null;
                    planes.head = head.next;
                }
                return removedNumber;
            }
            head = head.next;
        }
        return null;
    }

    @Override
    public boolean isPresent(String planeNumber) {
        Node head = planes.head;
        while (head != null) {
            if (head.data.getPlaneNumber().equals(planeNumber)) {
                return true;
            }
            head = head.next;
        }
        return false;
    }

    public static void main(String[] args) {
        String[] sorted = {
                "KGH1357,1:00",
                "AKC8888,1:00",
                "GBC1233,3:00",
                "MAU1357,3:00",
                "HKG8888,9:00",
                "NYC1233,2:00",
                "KGH1233,1:00"};
        Dispatcher dispatcher = new Dispatcher();
        for (String item : sorted) {
            String[] a = item.split(",");
            dispatcher.addPlane(a[0], a[1]);
        }
        System.out.println(dispatcher.size());
        System.out.println(dispatcher.isPresent("NYC1233"));
        System.out.println(dispatcher.isPresent("aaaa"));
        System.out.println(dispatcher.isEmpty());
        dispatcher.allocateLandingSlot("0:54");
        Node plane = dispatcher.planes.head;
        while (plane != null) {
            System.out.println(plane.data);
            plane = plane.next;
        }
    }
}

/* Add any additional helper classes here */
class LinkedList {
    Node head;
    int size;
    public LinkedList() {
        this.head = null;
        size = 0;
    }

    public LinkedList(Node head) {
        this.head = head;
    }

    public void insert(Node node) {
        if (this.head == null) {
            this.head = node;
            size++;
        } else if (this.head.next == null) {
            Node temp = this.head;
            if (temp.data.compareTo(node.data) < 0) {
                this.head.next = node;
                node.prev = this.head;
            } else {
                node.next = this.head;
                this.head.prev = node;
                this.head = node;
            }
            size++;
        } else {
            Node temp = this.head;
            while (temp.next != null) {
                if (temp.next.data.compareTo(node.data) > 0
                        && temp.data.compareTo(node.data) > 0) {
                    node.next = this.head;
                    this.head.prev = node;
                    this.head = node;
                    size++;
                    break;
                }
                if (temp.next.data.compareTo(node.data) > 0
                        && temp.data.compareTo(node.data) < 0) {
                    node.next = temp.next;
                    temp.next.prev = node;
                    node.prev = temp;
                    temp.next = node;
                    size++;
                    break;

                }
                if (temp.next.data.compareTo(node.data) <= 0
                        && temp.data.compareTo(node.data) <= 0) {
                    if (temp.next.next == null) {
                        node.prev = temp.next;
                        temp.next.next = node;
                        size++;
                        break;
                    }
                    ;
                }
                temp = temp.next;
            }
        }
    }
}

class Node {
    Plane data;
    Node next;
    Node prev;

    Node(Plane data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
}