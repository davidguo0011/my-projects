export interface CalendarDayTitleDate {
  firstDate: string;
  lastDate: string;
}
