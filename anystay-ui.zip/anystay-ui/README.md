# anystay-ui

[![NPM version](https://img.shields.io/npm/v/anystay-ui.svg?style=flat)](https://npmjs.org/package/anystay-ui)
[![NPM downloads](http://img.shields.io/npm/dm/anystay-ui.svg?style=flat)](https://npmjs.org/package/anystay-ui)

anystay ui framework

## Usage

TODO

## Options

TODO

## Development

```bash
# install dependencies
$ npm install

# develop library by docs demo
$ npm start

# build library source code
$ npm run build

# build library source code in watch mode
$ npm run build:watch

# build docs
$ npm run docs:build

# Locally preview the production build.
$ npm run docs:preview

# check your project for potential problems
$ npm run doctor
```

## LICENSE

MIT
